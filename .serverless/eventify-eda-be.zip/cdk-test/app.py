#!/usr/bin/env python3

from aws_cdk import App
from eventbridge_stack import EventBridgeStack

app = App()
EventBridgeStack(app, "EventBridgeStack")

app.synth()
