# IntApp-EDA


# Requerimientos
- Node JS y NPM (v21.1.0+)
- Python 3.10+

# Dependencias
- Marshmellow
- AWS CDK
- 

# Ejecutar
sudo python3 -m pip install -r requirements.txt && npm install -g aws-cdk && cdk bootstrap && cdk build \
cd ./lambda/ && python3 -m pip install -r requirements.txt \
