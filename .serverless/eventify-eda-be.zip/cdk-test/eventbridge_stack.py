from aws_cdk import (
    aws_events as events,
    aws_events_targets as targets,
    aws_lambda as _lambda,
    aws_iam as iam,
)
from aws_cdk import Stack
from constructs import Construct

class EventBridgeStack(Stack):

    def __init__(self, scope: Construct, id: str, **kwargs) -> None:
        super().__init__(scope, id, **kwargs)

        # definir la funcion Lambda que manejara los eventos
        event_handler_lambda = _lambda.Function(
            self, "EventHandlerLambda",
            runtime=_lambda.Runtime.PYTHON_3_10,
            handler="event_handler.lambda_handler",
            code=_lambda.Code.from_asset("lambda"),
            role=iam.Role.from_role_arn(self, "LabRole", "arn:aws:iam::747661705570:role/LabRole")  # TODO! mover a config?
        )

        # crear un bus de eventos
        event_bus = events.EventBus(
            self, "TestEventBus",
            event_bus_name="TestEventBus"
        )

        # definir la regla de EventBridge para capturar eventos
        rule = events.Rule(
            self, "MyRule",
            event_bus=event_bus,
            event_pattern={
                "source": ["eventify-eda-be"],
                "detail_type": ["test_event"]
            }
        )

        # agrega la lambda como target
        rule.add_target(targets.LambdaFunction(event_handler_lambda))
